OUTFIT BUDDY — ANDROID STUDIO PROJECT

What this is
- An Android app project that packages the existing Outfit Buddy offline web app.
- It opens the app from assets bundled inside the Android application.
- Wardrobe data and saved outfits remain on the device using browser local storage.
- No account or subscription is included.
- This is source code, not a signed APK or Play Store AAB.

Build an APK (for personal testing)
1. Install the latest stable Android Studio on a computer.
2. Unzip this folder.
3. In Android Studio choose File > Open and select the OutfitBuddy folder.
4. Allow Gradle sync to finish. Android Studio may download the Android Gradle Plugin and SDK.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press Run to install the app for testing.
7. To create a test APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
   Android Studio will show the output location when the build completes.

Prepare a Play Store release
- Use Build > Generate Signed Bundle / APK > Android App Bundle.
- A release AAB must be signed and tested before uploading to Play Console.
- Complete the store listing, content rating, data safety form, and privacy policy.
- Google Play account registration and publishing must be handled by an adult account owner (18+); a parent/guardian can manage this process.

Important notes
- Offline app screens and local features work from bundled files.
- The app does not include AI virtual try-on or live weather.
- Image selection uses Android's file picker. Photos selected by the user are handled by the app's local browser storage.
- Test image upload, backup/restore, and data persistence on real devices before release.
- Review the app's privacy disclosures and Play policies before public release.

Package name: com.outfitbuddy.app
Version: 1.0 (1)
Minimum Android: Android 7.0 (API 24)
