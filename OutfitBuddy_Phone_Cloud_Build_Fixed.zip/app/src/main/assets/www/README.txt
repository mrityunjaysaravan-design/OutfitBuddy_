# Outfit Buddy — Phone-ready PWA

## What is included
- `index.html`: the app
- `manifest.webmanifest`: install metadata
- `sw.js`: offline cache
- `icons/`: app icons

## Install on Android
This is a Progressive Web App (PWA), not an APK. To install it:
1. Publish the contents of this folder to a static HTTPS host (for example, GitHub Pages or Netlify).
2. Open the published HTTPS address in Chrome on your Android phone.
3. Open Chrome's menu and tap **Install app** or **Add to Home screen**.
4. Launch it from your home screen. It can then open in its own app-style window.

Opening `index.html` directly as a local file is useful for previewing, but browser security rules do not allow full PWA installation/offline service-worker behavior from a `file://` address.

## Privacy and backups
Wardrobe items and photos are stored in local browser storage on that device. Use Settings → Export backup regularly. Import the JSON backup on another device to move your wardrobe. The app does not upload photos to a server.

## Important limitations
Outfit suggestions use the item category, colour and style labels you select. They are not a human stylist or a visual AI clothing recognizer. Live weather and realistic virtual try-on are not connected.
